const companyToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTE2LCJlbWFpbCI6ImZyYW5jZXNjby5zZ2hlcnppQHRvcnJlc2NhbGxhLml0IiwiYmVnaW5fdGltZSI6IjIwMTktMDEtMDlUMjI6MzY6MDIuOTY0WiIsImlhdCI6MTU0NzA3MzM2MiwiZXhwIjoxNTQ3MTU5NzYyfQ.eEbF-C5K_IC3XBgzppnanCtDBF4wvjQR3SYax2g-sf0'
const userToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTExLCJlbWFpbCI6ImZyYW5jZXNjby5zZ2hlcnppQGdtYWlsLmNvbSIsImJlZ2luX3RpbWUiOiIyMDE5LTAxLTA5VDIyOjM4OjAwLjg0NVoiLCJpYXQiOjE1NDcwNzM0ODAsImV4cCI6MTU0NzE1OTg4MH0.PUwR50SKFnnrupQ7OsvdwvtQTvDNjkjsgiC3KjUCOiU'
const runOrganizerToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTE1LCJlbWFpbCI6ImZyYW5jZXNjby5zZ2hlcnppLmRldkBnbWFpbC5jb20iLCJiZWdpbl90aW1lIjoiMjAxOS0wMS0wOVQyMjozNzoyMC45MzRaIiwiaWF0IjoxNTQ3MDczNDQwLCJleHAiOjE1NDcxNTk4NDB9.SSrNMPAvUI6IeKm56eJ8xrLSfxCziwsNdS-YlSsQ8Wc'
const companyMail = 'francesco.sgherzi@torrescalla.it'
const userMail = 'francesco.sgherzi@gmail.com'
const runOrganizerMail = 'francesco.sgherzi.dev@gmail.com'
const password = 'asdfasdf'

const LOCAL_BASE_URL = 'http://localhost:12345/v1/'
const HEROKU_BASE_URL = 'https://data4halp.herokuapp.com/v1/'

module.exports = {
  userToken,
  companyToken,
  runOrganizerToken,
  LOCAL_BASE_URL,
  HEROKU_BASE_URL,
  companyMail,
  runOrganizerMail,
  password,
  userMail
}