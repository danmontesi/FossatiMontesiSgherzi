class Config{
  static const  String BASE_URL = "https://data4halp.herokuapp.com/v1";
  //static const  String BASE_URL = "http://192.168.164.4:12345";
}