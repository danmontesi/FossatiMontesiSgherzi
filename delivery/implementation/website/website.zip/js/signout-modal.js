
  function signOut(){
    deleteAllCookies();
    document.location.href = "index.html";
    alert("You have logged out.");/*displays info */
    
  }
